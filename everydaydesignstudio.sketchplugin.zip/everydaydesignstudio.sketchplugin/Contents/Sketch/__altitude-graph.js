var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/altitude-graph.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/altitude-graph.js":
/*!*******************************!*\
  !*** ./src/altitude-graph.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);


var Artboard = __webpack_require__(/*! sketch/dom */ "sketch/dom").Artboard;

var Shape = __webpack_require__(/*! sketch/dom */ "sketch/dom").Shape;

var ShapePath = __webpack_require__(/*! sketch/dom */ "sketch/dom").ShapePath;

var Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style;

var library = __webpack_require__(/*! ./helper-functions.js */ "./src/helper-functions.js"); // documentation: https://developer.sketchapp.com/reference/api/
// var input2 = sketch.UI.getSelectionFromUser("Howdy", ["hello", "24"], 1)
// Global variables


var artboardH = 150;
var artboardW = 1280;
var newArtboardPadding = 25;
var RADIUS = 4;
var HEIGHEST;
/* harmony default export */ __webpack_exports__["default"] = (function (_ref) {
  var api = _ref.api,
      command = _ref.command,
      document = _ref.document,
      plugin = _ref.plugin,
      scriptPath = _ref.scriptPath,
      scriptURL = _ref.scriptURL,
      selection = _ref.selection;
  // Current Page
  var page = document.currentPage(); // Selected Layers

  var selectedLayers = Array.fromNSArray(selection); // Make sure only 1 artboard / layer is selected
  // print(selectedLayers[0])

  if (selection.count() != 1) {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Select 1 (and only 1) artboard 7.0");
    stop;
  } else {
    HEIGHEST = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.getStringFromUser("What is the heighest altitude?", "000.00");
    var inputString = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.getStringFromUser("Paste in a list of ids and altitude for the Altitude Graph", ""); //   9013	478.88\n\
    //   9041	845.81\n\
    //   9069	1237.5\n\
    //   9096	1838.94"
    // )

    var idAltitudeList = processInput(inputString);
    var artboard = library.createNewArtboardBelow(page, selectedLayers[0], artboardW, artboardH, newArtboardPadding);
    createRectanglesWithIds(artboard, idAltitudeList); // ✅ Success!

    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("✅ Altitude Graph created with " + idAltitudeList.length + " altitudes");
  }
}); // Process the inputed data - separating the picture_id from the colors

function processInput(input) {
  var parsedArray = input.split('\n');
  var count = parsedArray.length; // print("Total altitudes: " + count)

  var idAltitudeList = [];
  var i;

  for (i = 0; i < count; i++) {
    var item = parsedArray[i].split('\t'); // print(item[0] + " | " + item[1])

    idAltitudeList.push(item);
  }

  return idAltitudeList;
} // Iterate through all rectangle info


function createRectanglesWithIds(artboard, idAltList) {
  var count = idAltList.length;
  var heighest = idAltList[count - 1][1];
  print('THE HEIGHTEST IS: ' + heighest); // let width = artboardW / count
  // let distance = (1280-(128*4))/129

  var distance = (artboardW - count * RADIUS) / (count + 1);
  print("THE DISTANCE IS: " + distance);
  var i; // TODO - fix this

  for (i = 0; i < count; i++) {
    // layer name,     artboard,              x,                                  y,                                                    w,    h
    createRect("a_" + idAltList[i][0], artboard, "#000000", distance / 2 + RADIUS * i + distance * i, artboardH - idAltList[i][1] / heighest * artboardH, RADIUS, RADIUS);
  }
} // Creates a single rectangle and places on given artboard


function createRect(name, artboard, color, posX, posY, width, height) {
  var myShape = new Shape({
    name: name,
    parent: artboard,
    frame: {
      x: posX,
      y: posY,
      width: width,
      height: height
    },
    style: {
      fills: [color],
      borders: []
    }
  });
  print(myShape.radius); // myShape.cornerRadiusFloat = RADIUS/2
}

/***/ }),

/***/ "./src/helper-functions.js":
/*!*********************************!*\
  !*** ./src/helper-functions.js ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Artboard = __webpack_require__(/*! sketch/dom */ "sketch/dom").Artboard;

var Shape = __webpack_require__(/*! sketch/dom */ "sketch/dom").Shape; // var ShapePath = require('sketch/dom').ShapePath
// var Style = require('sketch/dom').Style
// Extends the Array class


Array.fromNSArray = function (nsArray) {
  var array = [];

  for (var i = 0; i < nsArray.count(); i++) {
    array.push(nsArray[i]);
  }

  return array;
}; // Creates new artboard beside currently selected artboard


function createNewArtboardBelow(page, layer, w, h, padding) {
  var xpos = layer.frame().x();
  var ypos = layer.frame().y() + layer.frame().height() + padding;
  var myArtboard = new Artboard({
    parent: page,
    frame: {
      x: xpos,
      y: ypos,
      width: w,
      height: h
    } // background.color: "255,0,255,120"

  });
  return myArtboard;
}

module.exports = {
  createNewArtboardBelow: createNewArtboardBelow
};

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__altitude-graph.js.map