var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/dominant-color-transfer.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/dominant-color-transfer.js":
/*!****************************************!*\
  !*** ./src/dominant-color-transfer.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);


var Artboard = __webpack_require__(/*! sketch/dom */ "sketch/dom").Artboard;

var Shape = __webpack_require__(/*! sketch/dom */ "sketch/dom").Shape;

var ShapePath = __webpack_require__(/*! sketch/dom */ "sketch/dom").ShapePath;

var Style = __webpack_require__(/*! sketch/dom */ "sketch/dom").Style; // documentation: https://developer.sketchapp.com/reference/api/
// GLOBAL VALUES
// space between artboards


var newArtboardPadding = 50; // width & height of artboards

var artboardWH = 400; // max width & height, that all the boxes are a percentage of

var maxWidthHeight = 300; // Creates new artboard beside currently selected artboard

function createNewArtboardBeside(page, layer, w, h) {
  var padding = newArtboardPadding;
  var xpos = layer.frame().x() + layer.frame().width() + padding;
  var ypos = layer.frame().y();
  var myArtboard = new Artboard({
    parent: page,
    frame: {
      x: xpos,
      y: ypos,
      width: w,
      height: h
    }
  });
  return myArtboard;
} // Creates a single rectangle and places on given artboard


function createRect(artboard, color, percent, posX, posY) {
  // maximum width & height, that all the boxes are a percentage of
  var max = maxWidthHeight;
  var myShape = new Shape({
    name: 'color box',
    parent: artboard,
    frame: {
      x: posX,
      y: posY,
      width: max * percent,
      height: max * percent
    },
    style: {
      fills: [color],
      borders: []
    }
  });
} // Iterate through all rectangle info


function createRectangles(artboard, colors, percents) {
  if (colors.length == 5 && percents.length == 5) {
    createRect(artboard, colors[0], percents[0], 133, 121);
    createRect(artboard, colors[1], percents[1], 170, 170);
    createRect(artboard, colors[2], percents[2], 130, 195);
    createRect(artboard, colors[3], percents[3], 150, 219);
    createRect(artboard, colors[4], percents[4], 170, 247);
  } else {
    for (var i = 0; i < colors.length; i++) {
      var posX = Math.floor(Math.random() * 100 + 125);
      var posY = Math.floor(Math.random() * 75 + 125);
      createRect(artboard, colors[i], percents[i], posX, posY);
    }
  }
} // Process the inputted data and call the shape building functions


function processString(inputStr) {
  var rawElements = inputStr.replace('\n', '').split('][');
  var colorsStr = rawElements[0].slice(2, -1);
  var colors = colorsStr.split("', '");
  colors.forEach(rgbToHex);
  var percentsStr = rawElements[1].slice(0, -1);
  var percents = percentsStr.split(',');
  return [colors, percents];
} // Helpers for RGB to Hex


function rgbToHex(str, index, arr) {
  var colors = str.split(', ');
  var r = componentToHex(colors[0]);
  var g = componentToHex(colors[1]);
  var b = componentToHex(colors[2]);
  arr[index] = "#" + r + g + b;
}

function componentToHex(c) {
  c = parseInt(c, 10);
  var hex = c.toString(16);
  return hex.length == 1 ? "0" + hex : hex;
} // The main() of the Sketch plugin


/* harmony default export */ __webpack_exports__["default"] = (function (_ref) {
  var api = _ref.api,
      command = _ref.command,
      document = _ref.document,
      plugin = _ref.plugin,
      scriptPath = _ref.scriptPath,
      scriptURL = _ref.scriptURL,
      selection = _ref.selection;
  print("\n\n--------------------------------------");
  sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Still needs to be implemented");
  stop; // Current Page

  var page = document.currentPage(); // Selected Layers

  var selectedLayers = Array.fromNSArray(selection); // Make sure only 1 artboard / layer is selected

  print(selectedLayers[0]);

  if (selection.count() != 1) {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("Select 1 (and only 1) artboard"); // sketch.UI.message("Jordan White this is running from the test.")

    stop;
  } else {
    var inputString = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.getStringFromUser("Please paste in dominant color output\nExample data", "");
    var results = processString(inputString);
    var colors = results[0];
    var percents = results[1];
    print(colors);
    print(percents);
    var artboard = createNewArtboardBeside(page, selectedLayers[0], artboardWH, artboardWH);
    createRectangles(artboard, colors, percents); // ✅ Success!

    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.UI.message("✅ Dominant Color finished");
  }
});
/* 
 *
 * Currently unused UI functions
 *
 */

Array.fromNSArray = function (nsArray) {
  var array = [];

  for (var i = 0; i < nsArray.count(); i++) {
    array.push(nsArray[i]);
  }

  return array;
};

function loadLocalImage(_ref2) {
  var scriptPath = _ref2.scriptPath,
      filePath = _ref2.filePath;
  var basePath = scriptPath.stringByDeletingLastPathComponent().stringByDeletingLastPathComponent().stringByDeletingLastPathComponent();
  return NSImage.alloc().initWithContentsOfFile(basePath + "/" + filePath);
}

function showModalWithSelectionAndOptions(_ref3) {
  var scriptPath = _ref3.scriptPath;
  var alert = NSAlert.alloc().init();
  alert.setMessageText("Apply Mockup");
  alert.setInformativeText("Choose an Artboard to apply into the selected shape");
  alert.addButtonWithTitle("Apply");
  alert.addButtonWithTitle("Cancel");
  alert.icon = loadLocalImage({
    scriptPath: scriptPath,
    filePath: "Contents/Resources/logo.png"
  });
  return alert.runModal();
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__dominant-color-transfer.js.map